## Hello, Enact

The completed Hello, Enact app from the Enact tutorial.

Run `npm install` then `npm run serve` to have the app running on [http://localhost:8080](http://localhost:8080), where you can view it in your browser.

---

This project was bootstrapped with the Enact [cli](https://github.com/enactjs/cli).
