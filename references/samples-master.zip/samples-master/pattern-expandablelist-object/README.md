## Enact ExpandableList with data in Object format

Sample which shows the ExpandableList with data in Object format is provided here.

Run `npm install` then `npm run serve` to have the app running on [http://localhost:8080](http://localhost:8080), where you can view it in your browser.

#### Enact Components Used
- `moonstone/Panels/Panel`
- `moonstone/ExpandableList`

---

This project was bootstrapped with the Enact [cli](https://github.com/enactjs/cli).
