const decreaseIndex = () => {
	return {
		type: 'DECREASE_INDEX'
	};
};

const increaseIndex = () => {
	return {
		type: 'INCREASE_INDEX'
	};
};

export {
	decreaseIndex,
	increaseIndex
};
