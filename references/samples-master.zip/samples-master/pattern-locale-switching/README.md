# Locale Switching Sample

This sample is a very simple sample with 3 components (one `Input` and two
`Button`s). This sample will demonstrate how to update the locale of an app
using either `context` or `redux`.

> NOTE: An app should adopt one of these two approaches, not both.
