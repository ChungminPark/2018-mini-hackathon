export const updateLocale = locale => {
	return {
		type: 'UPDATE_LOCALE',
		payload: locale
	};
};
